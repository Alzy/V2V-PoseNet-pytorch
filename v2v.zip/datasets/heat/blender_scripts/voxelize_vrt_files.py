import os
import subprocess


def run_voxelizer(directory):
    # Loop through all files in the given directory
    for filename in os.listdir(directory):
        if filename.endswith(".vrt_hand.bin"):
            abs_path = os.path.join(directory, filename)
            base_name = os.path.splitext(os.path.basename(abs_path))[0]
            output_path = os.path.join(directory, f"{base_name}.vox.bin")
            command = f"HEATVoxelizerWGPU.exe \"{abs_path}\" \"{output_path}\""

            # Skip if the output file already exists
            if os.path.exists(output_path):
                print(f"Skipping {abs_path}, output file already exists.")
                continue

            # Execute the command
            subprocess.run(command, shell=True)
            print(f"Processed {abs_path}")


if __name__ == "__main__":
    # Replace these with your directory paths
    directory_paths = [
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand1',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand2',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand3',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand4',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand5',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand6',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand7',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand8',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand9',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand10',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand11',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand12',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand13',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand14',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand16',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand17',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand18',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand19',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand20',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand21',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand22',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand23',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand24',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand25',
        # 'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand26',
        'Z:\\Jeffs corner\\hand datasets\\hands\\2-finger\\hand27'
        # Add more paths as needed
    ]

    for path in directory_paths:
        run_voxelizer(path)
